#pragma once
#include <Windows.h>
enum  ElementColor :COLORREF {
	BLACK = RGB(0, 0, 0), RED = RGB(255, 0, 0),
	GREEN = RGB(0, 255, 0), BLUE = RGB(0, 0, 255),
	PALEBLUE =RGB(142 ,229, 238),GOLD=RGB(255 ,215 ,0),
	VIOLET	=RGB(153, 50, 204)
};
