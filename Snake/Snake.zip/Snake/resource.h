//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Snake.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_STRINGGAMEOVER              101
#define IDR_MAINFRAME                   128
#define IDR_SnakeTYPE                   130
#define IDD_DIALOG1                     311
#define IDD_DIALOG2                     314
#define IDC_SLIDER1                     1003
#define IDC_STATIC3                     1006
#define ID_GAME_START                   32775
#define ID_GAME_PAUSE                   32776
#define ID_GAME_CONTINUE                32777
#define ID_OPTIONS_SNAKECOLOR           32778
#define ID_OPTIONS_SNAKESPEED           32779
#define ID_OPTIONS_FOODCOLOR            32780
#define ID_Menu                         32781
#define ID_GAME_RESTART                 32782
#define ID_SNAKECOLOR_YELLOW            32783
#define ID_SNAKECOLOR_GREEN             32784
#define ID_SNAKECOLOR_RED               32785
#define ID_SNAKESPEED_YELLOW            32786
#define ID_SNAKESPEED_GREEN             32787
#define ID_SNAKESPEED_BLUE              32788
#define ID_SNAKESPEED_RED               32789
#define ID_SNAKECOLOR_BLUE              32790
#define ID_OPTIONS_SIZEOFGRID           32791
#define ID_OPTIONS_FOODCOLOR32792       32792
#define ID_FOODCOLOR_YELLOW             32793
#define ID_FOODCOLOR_GREEN              32794
#define ID_FOODCOLOR_BLUE               32795

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        316
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
